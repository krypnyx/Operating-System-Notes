
#include<stdio.h>
#include <stdlib.h>
#include<sys/types.h>
#include<pthread.h>
int sum;

#define HALF 5
#define MAX 10

int a[10] = {15,55,5,35,25,28,1, 33, 22, 18};

int min,min1,min2;

int threadno=0;

void * findmin(void *p)
{  
   int slice = threadno++;
   if(slice == 0)
    {   int i; min1 = a[0];
        for(i=1;i<HALF;i++)
         if(a[i] < min1) {min1 = a[i];}
    }
   else if (slice == 1)
    {   int i;min2 = a[HALF];
        for(i=HALF+1;i<MAX;i++)
          if(min2>a[i])  {min2 = a[i];}
    }
}

int main(int argc, char *argv[])
{
    pthread_t tid1,tid2; 
    pthread_attr_t attr; 


    pthread_attr_init(&attr);

    int slice = 0;

    pthread_create(&tid1,&attr,findmin,(void *)0);

    
    
    
    pthread_create(&tid2,&attr,findmin, NULL);

    pthread_join(tid1,NULL);
    pthread_join(tid2,NULL);

    if(min1 < min2) min = min1;
    else min = min2;

    printf("Minimum = %d %d %d \n",min,min1,min2);

    return 0;

}



